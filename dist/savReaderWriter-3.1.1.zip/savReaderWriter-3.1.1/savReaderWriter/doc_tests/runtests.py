import nose
result = nose.run()
